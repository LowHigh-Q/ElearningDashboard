import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaBook, FaHome, FaBars, FaTimes, FaUser } from 'react-icons/fa';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="navbar navbar-light bg-white shadow-sm">
      <div className="container">
        <div className="d-flex justify-content-between align-items-center">
          <Link className="navbar-brand d-flex align-items-center" to="/">
            <FaBook className="me-2" />
            <span>E-Learning</span>
          </Link>
          
          {/* Hamburger menu button positioned to the right */}
          <div className="d-flex align-items-center">
            <button 
              className="navbar-toggler border-0 bg-transparent ms-2"
              type="button"
              onClick={toggleMenu}
            >
              {isMenuOpen ? <FaTimes /> : <FaBars />}
            </button>
          </div>
        </div>
        
        {/* Navigation links */}
        <div className={`collapse navbar-collapse ${isMenuOpen ? 'show' : ''}`}>
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link className="nav-link" to="/">
                <FaHome className="me-1" /> Home
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/courses">
                <FaBook className="me-1" /> Courses
              </Link>
            </li>
          </ul>
          
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link" to="/login">
                <FaBars className="me-1" /> Login
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/register">
                <FaUser className="me-1" /> Register
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;