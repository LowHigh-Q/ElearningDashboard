// components/CourseCard.js
import React from 'react';
import { Link } from 'react-router-dom';
import { FaStar } from 'react-icons/fa';

const CourseCard = ({ course }) => {
  // Ensure rating is a valid number
  const rating = typeof course.Rating === 'number' && !isNaN(course.Rating) ? course.Rating : 0;

  return (
    <div className="col-md-4 mb-4">
      <div className="course-card">
        <div className="course-image">
          <img 
            src={course.ImageUrl || '/default-course-image.jpg'} 
            alt={course.CourseName || 'Course'} 
            className="img-fluid" 
          />
        </div>
        <div className="course-content">
          <h3 className="course-title">{course.CourseName || 'Unnamed Course'}</h3>
          <p className="course-description">{course.Description || 'No description available'}</p>
          <div className="course-meta">
            <span>
              <i className="bi bi-person"></i> {course.Instructor || 'Unknown Instructor'}
            </span>
            <span>
              <i className="bi bi-clock"></i> {course.Duration || 'Unknown Duration'}
            </span>
          </div>
          <div className="course-footer">
            <span className="course-rating">
              {[...Array(Math.floor(rating))].map((_, i) => (
                <FaStar key={i} className="text-warning" />
              ))}
              {rating % 1 === 0.5 && (
                <FaStar className="text-warning" style={{ width: '50%' }} />
              )}
              {rating}
            </span>
            <span className="course-category">{course.Category || 'Uncategorized'}</span>
          </div>
          <Link 
            to={`/course/${course.CourseId}`} 
            className="btn btn-primary w-100 mt-3"
          >
            Learn More
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CourseCard;