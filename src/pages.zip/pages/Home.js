import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import CourseCard from '../components/CourseCard';
import { featuredCourses } from '../data/courses';

const Home = () => {
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    // 在实际应用中，你会从 API 获取课程
    setCourses(featuredCourses);
  }, []);

  return (
    <div className="home-page">
      <header className="header">
        <h1>Welcome to E-Learning Dashboard</h1>
        <p>Discover and enroll in courses to enhance your skills</p>
      </header>
      
      <section className="featured-courses container mb-5">
        <h2 className="text-center mb-4">Featured Courses</h2>
        <div className="row">
          {courses.map(course => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      </section>
      
      <section className="call-to-action py-5">
        <div className="container text-center">
          <h2 className="mb-4">Ready to start learning?</h2>
          <p className="mb-4">Sign up today and unlock access to our comprehensive course library.</p>
          <Link className="btn btn-primary btn-lg px-4" to="/register">
            Register Now
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;