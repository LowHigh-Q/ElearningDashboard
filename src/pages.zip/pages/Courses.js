// components/Courses.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCourses } from '../slices/courseSlice';
import CourseCard from '../components/CourseCard';
import { Link } from 'react-router-dom';

const Courses = () => {
  const dispatch = useDispatch();
  const { courses, loading, error } = useSelector(state => state.courses);

  useEffect(() => {
    dispatch(fetchCourses());
  }, [dispatch]);

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading courses...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <h2>Oops! Something went wrong</h2>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="courses-page container">
      <header className="page-header text-center my-5">
        <h1>All Courses</h1>
        <p>Explore our comprehensive library of courses</p>
      </header>
      
      <div className="row">
        {courses.map(course => (
          <CourseCard key={course.CourseId} course={course} />
        ))}
      </div>
    </div>
  );
};

export default Courses;