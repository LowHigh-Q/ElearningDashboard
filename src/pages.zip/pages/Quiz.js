import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { fetchCourse } from '../slices/courseSlice';
import { updateCourseProgress } from '../slices/progressSlice';
import QuizQuestion from '../components/QuizQuestion';
import { FaCheck, FaTimes, FaRetweet } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';

const Quiz = () => {
  const { id } = useParams();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [userAnswers, setUserAnswers] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const { user } = useSelector(state => state.auth);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchCourse(id));
  }, [dispatch, id]);

  const course = useSelector(state => state.courses.course);
  const progress = useSelector(state => state.progress.progress);

  if (!course || !course.questions) {
    return <div>Loading quiz...</div>;
  }

  const handleAnswerSelect = (answerIndex) => {
    const updatedAnswers = [...userAnswers];
    updatedAnswers[currentQuestion] = answerIndex;
    setUserAnswers(updatedAnswers);
  };

  const handleNextQuestion = () => {
    if (currentQuestion < course.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
      // Calculate score
      let score = 0;
      course.questions.forEach((question, index) => {
        if (userAnswers[index] !== undefined && question.options[userAnswers[index]].isCorrect) {
          score++;
        }
      });
      setScore(score);
      
      // Update course progress
      const enrollment = progress.find(p => p.CourseId === parseInt(id));
      if (enrollment) {
        dispatch(updateCourseProgress({
          enrollmentId: enrollment.EnrollmentId,
          percentage: 100 // Set to 100% after completing quiz
        }));
      }
    }
  };

  const handleRestartQuiz = () => {
    setCurrentQuestion(0);
    setUserAnswers([]);
    setShowResults(false);
  };

  const currentQuestionData = course.questions[currentQuestion];
  const isLastQuestion = currentQuestion === course.questions.length - 1;

  return (
    <div className="quiz-container">
      <header className="quiz-header">
        <h1>{course.CourseName} - Quiz</h1>
        <p>Test your knowledge on this course</p>
      </header>
      
      {!showResults ? (
        <>
          <div className="quiz-progress">
            <div className="quiz-step">
              {[0, 1, 2, 3, 4].map(index => (
                <span key={index} className={currentQuestion === index ? 'active' : ''}>{index + 1}</span>
              ))}
            </div>
            <div className="quiz-question-counter">
              Question {currentQuestion + 1} of {course.questions.length}
            </div>
          </div>
          
          <QuizQuestion
            question={currentQuestionData}
            index={currentQuestion}
            userAnswer={userAnswers[currentQuestion]}
            onSelectAnswer={handleAnswerSelect}
          />
          
          <div className="quiz-navigation">
            <button 
              className="btn btn-secondary" 
              onClick={handleNextQuestion}
              disabled={userAnswers[currentQuestion] === undefined}
            >
              {isLastQuestion ? 'Finish Quiz' : 'Next Question'}
            </button>
          </div>
        </>
      ) : (
        <div className="quiz-results">
          <div className="results-header">
            <h2>Quiz Results</h2>
            <div className="results-score">
              <span className="score-value">{score}</span>/{course.questions.length}
            </div>
          </div>
          
          <div className="results-details">
            <div className="results-item">
              <FaCheck className="results-icon correct" />
              <div className="results-content">
                <h3>Correct Answers</h3>
                <p>{score} out of {course.questions.length}</p>
              </div>
            </div>
            <div className="results-item">
              <FaTimes className="results-icon incorrect" />
              <div className="results-content">
                <h3>Incorrect Answers</h3>
                <p>{course.questions.length - score}</p>
              </div>
            </div>
          </div>
          
          <div className="results-actions">
            <button className="btn btn-secondary" onClick={handleRestartQuiz}>
              <FaRetweet /> Retry Quiz
            </button>
            <Link to={`/progress`} className="btn btn-primary">
              View Progress
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default Quiz;