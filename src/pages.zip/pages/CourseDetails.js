import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCourse, enrollInCourse } from '../slices/courseSlice';
import { FaBookOpen, FaUserGraduate, FaCertificate, FaClock, FaStar } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const CourseDetails = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const { course, loading, error } = useSelector(state => state.courses);
  const { isAuthenticated, user } = useSelector(state => state.auth);

  useEffect(() => {
    dispatch(fetchCourse(id));
  }, [dispatch, id]);

  const handleEnroll = () => {
    if (user && course) {
      dispatch(enrollInCourse({ userId: user.UserId, courseId: course.CourseId }));
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading course details...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <h2>Oops! Something went wrong</h2>
        <p>{error}</p>
      </div>
    );
  }

  if (!course) {
    return <div>Course not found</div>;
  }

  return (
    <div className="course-details">
      <div className="course-header">
        <h1>{course.CourseName}</h1>
        <div className="course-meta">
          <span>
            <FaUserGraduate /> Instructor: {course.Instructor}
          </span>
          <span>
            <FaClock /> Duration: {course.Duration}
          </span>
          <span>
            <FaStar /> Rating: {course.Rating}
          </span>
        </div>
      </div>
      
      <div className="course-content">
        <div className="course-info">
          <div className="course-image">
            <img src={course.ImageUrl} alt={course.CourseName} />
          </div>
          <div className="course-description">
            <h2>About this course</h2>
            <p dangerouslySetInnerHTML={{ __html: course.Description }}></p>
            <div className="course-features">
              <div className="feature-item">
                <FaCertificate className="feature-icon" />
                <div className="feature-content">
                  <h3>Certificate of Completion</h3>
                  <p>Earn a certificate upon completion of this course</p>
                </div>
              </div>
              <div className="feature-item">
                <FaBookOpen className="feature-icon" />
                <div className="feature-content">
                  <h3>Interactive Content</h3>
                  <p>Engage with interactive lessons and quizzes</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="course-sidebar">
          <div className="course-enrollment">
            {isAuthenticated ? (
              course.enrolled ? (
                <Link to={`/quiz/${course.CourseId}`} className="btn btn-primary btn-block">
                  Start Course
                </Link>
              ) : (
                <button onClick={handleEnroll} className="btn btn-primary btn-block">
                  Enroll Now
                </button>
              )
            ) : (
              <Link to="/login" className="btn btn-primary btn-block">
                Login to Enroll
              </Link>
            )}
            <div className="course-price">
              {course.Price === 0 ? 'Free' : `$${course.Price}`}
            </div>
            <div className="course-stats">
              <div className="stat-item">
                <span className="stat-value">{course.Students}k</span>
                <span className="stat-label">Students</span>
              </div>
              <div className="stat-item">
                <span className="stat-value">{course.Reviews}k</span>
                <span className="stat-label">Reviews</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetails;