import React from 'react';
import LoginForm from '../components/LoginForm';
import { Link } from 'react-router-dom';
import { FaArrowLeft } from 'react-icons/fa';

const Login = () => {
  const handleLogin = (values) => {
    console.log('Login with:', values);
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-header">
          <h1>Welcome Back</h1>
          <p>Login to continue learning</p>
        </div>
        
        <LoginForm onSubmit={handleLogin} />
        
        <div className="auth-footer">
          <p>Don't have an account? <Link to="/register">Register</Link></p>
          <Link to="/" className="back-link">
            <FaArrowLeft /> Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;