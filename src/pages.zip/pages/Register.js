import React from 'react';
import RegisterForm from '../components/RegisterForm';
import { Link } from 'react-router-dom';
import { FaArrowLeft } from 'react-icons/fa';

const Register = () => {
  const handleRegister = (values) => {
    console.log('Register with:', values);
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-header">
          <h1>Create Account</h1>
          <p>Start your learning journey with us</p>
        </div>
        
        <RegisterForm onSubmit={handleRegister} />
        
        <div className="auth-footer">
          <p>Already have an account? <Link to="/login">Login</Link></p>
          <Link to="/" className="back-link">
            <FaArrowLeft /> Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Register;