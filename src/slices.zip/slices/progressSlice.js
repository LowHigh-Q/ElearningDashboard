import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { progressApi, enrollmentApi } from '../services/api';

const initialState = {
  progress: [],
  loading: false,
  error: null
};

export const fetchUserProgress = createAsyncThunk(
  'progress/fetchUser',
  async (userId, { rejectWithValue }) => {
    try {
      // First get all enrollments for the user
      const enrollmentsResponse = await enrollmentApi.getEnrollmentsByUser(userId);
      
      // Then get progress for each enrollment
      const progressPromises = enrollmentsResponse.data.map(enrollment => 
        progressApi.getProgressByEnrollment(enrollment.EnrollmentId)
      );
      
      const progressResponses = await Promise.all(progressPromises);
      
      // Combine enrollment and progress data
      const combinedData = enrollmentsResponse.data.map((enrollment, index) => ({
        ...enrollment,
        progress: progressResponses[index].data
      }));
      
      return combinedData;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch progress');
    }
  }
);

export const updateCourseProgress = createAsyncThunk(
  'progress/update',
  async ({ enrollmentId, percentage }, { rejectWithValue }) => {
    try {
      const response = await progressApi.updateProgress(enrollmentId, percentage);
      return { enrollmentId, progress: response.data };
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to update progress');
    }
  }
);

const progressSlice = createSlice({
  name: 'progress',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchUserProgress.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUserProgress.fulfilled, (state, action) => {
        state.loading = false;
        state.progress = action.payload;
      })
      .addCase(fetchUserProgress.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(updateCourseProgress.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateCourseProgress.fulfilled, (state, action) => {
        state.loading = false;
        // Update the specific enrollment's progress
        state.progress = state.progress.map(item => 
          item.EnrollmentId === action.payload.enrollmentId ? 
            { ...item, progress: action.payload.progress } : item
        );
      })
      .addCase(updateCourseProgress.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  }
});

export default progressSlice.reducer;