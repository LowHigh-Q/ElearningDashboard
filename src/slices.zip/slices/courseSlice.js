// slices/courseSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { coursesApi } from '../services/api';

const initialState = {
  courses: [],
  course: null,
  loading: false,
  error: null
};

// Define async thunks
export const fetchCourses = createAsyncThunk(
  'courses/fetchAll',
  async (_, { rejectWithValue }) => {
    try {
      const response = await coursesApi.getAllCourses();
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch courses');
    }
  }
);

export const fetchCourse = createAsyncThunk(
  'courses/fetchById',
  async (courseId, { rejectWithValue }) => {
    try {
      const response = await coursesApi.getCourseById(courseId);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Course not found');
    }
  }
);

export const enrollInCourse = createAsyncThunk(
  'courses/enroll',
  async (enrollmentData, { rejectWithValue }) => {
    try {
      const response = await coursesApi.enrollUser(enrollmentData.userId, enrollmentData.courseId);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Enrollment failed');
    }
  }
);

const courseSlice = createSlice({
  name: 'courses',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchCourses.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCourses.fulfilled, (state, action) => {
        state.loading = false;
        state.courses = action.payload;
      })
      .addCase(fetchCourses.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(fetchCourse.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCourse.fulfilled, (state, action) => {
        state.loading = false;
        state.course = action.payload;
      })
      .addCase(fetchCourse.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(enrollInCourse.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(enrollInCourse.fulfilled, (state, action) => {
        state.loading = false;
        // Update courses state if needed
      })
      .addCase(enrollInCourse.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  }
});

export default courseSlice.reducer;